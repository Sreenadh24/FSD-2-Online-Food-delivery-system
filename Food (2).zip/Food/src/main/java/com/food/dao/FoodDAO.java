package com.food.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.food.model.Food;

public class FoodDAO {
    public boolean addFood(Food food) throws SQLException {
        String sql = "INSERT INTO food (name, description, price, category, image) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            bindFood(ps, food);
            return ps.executeUpdate() == 1;
        }
    }

    public List<Food> getAllFood() throws SQLException {
        String sql = "SELECT food_id, name, description, price, category, image FROM food ORDER BY food_id";
        List<Food> foodList = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                foodList.add(readFood(rs));
            }
        }
        return foodList;
    }

    public Food getFoodById(int foodId) throws SQLException {
        String sql = "SELECT food_id, name, description, price, category, image FROM food WHERE food_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, foodId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? readFood(rs) : null;
            }
        }
    }

    public boolean updateFood(Food food) throws SQLException {
        String sql = "UPDATE food SET name = ?, description = ?, price = ?, category = ?, image = ? WHERE food_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            bindFood(ps, food);
            ps.setInt(6, food.getFoodId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean deleteFood(int foodId) throws SQLException {
        String sql = "DELETE FROM food WHERE food_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, foodId);
            return ps.executeUpdate() == 1;
        }
    }

    private static Food readFood(ResultSet rs) throws SQLException {
        return new Food(rs.getInt("food_id"), rs.getString("name"),
                rs.getString("description"), rs.getDouble("price"),
                rs.getString("category"), rs.getString("image"));
    }

    private static void bindFood(PreparedStatement ps, Food food) throws SQLException {
        ps.setString(1, food.getName());
        ps.setString(2, food.getDescription());
        ps.setDouble(3, food.getPrice());
        ps.setString(4, food.getCategory());
        ps.setString(5, food.getImage());
    }
}
