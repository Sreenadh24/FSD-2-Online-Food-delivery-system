package com.food.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.food.model.CartItem;
import com.food.model.Order;

public class OrderDAO {
    public int placeOrder(Order order, List<CartItem> cart) throws SQLException {
        if (cart == null || cart.isEmpty()) {
            throw new IllegalArgumentException("Your cart is empty.");
        }

        String orderSql = "INSERT INTO orders (user_id, total_amount, status) VALUES (?, ?, ?)";
        String itemSql = "INSERT INTO order_items (order_id, food_id, quantity, price) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                BigDecimal total = BigDecimal.ZERO;
                String priceSql = "SELECT price FROM food WHERE food_id = ? FOR UPDATE";
                try (PreparedStatement priceStatement = con.prepareStatement(priceSql)) {
                    for (CartItem item : cart) {
                        if (item == null || item.getFoodId() <= 0
                                || item.getQuantity() < 1 || item.getQuantity() > 50) {
                            throw new IllegalArgumentException("A cart item has an invalid quantity or ID.");
                        }
                        priceStatement.setInt(1, item.getFoodId());
                        try (ResultSet result = priceStatement.executeQuery()) {
                            if (!result.next()) {
                                throw new IllegalArgumentException("A food item in your cart is no longer available.");
                            }
                            BigDecimal currentPrice = result.getBigDecimal("price");
                            item.getFood().setPrice(currentPrice.doubleValue());
                            total = total.add(currentPrice.multiply(BigDecimal.valueOf(item.getQuantity())));
                        }
                    }
                }
                order.setTotalAmount(total.doubleValue());

                int orderId;
                try (PreparedStatement ps = con.prepareStatement(orderSql, new String[] {"ORDER_ID"})) {
                    ps.setInt(1, order.getUserId());
                    ps.setBigDecimal(2, total);
                    ps.setString(3, "Pending");
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("The database did not return the new order ID.");
                        }
                        orderId = keys.getInt(1);
                    }
                }

                try (PreparedStatement ps = con.prepareStatement(itemSql)) {
                    for (CartItem item : cart) {
                        ps.setInt(1, orderId);
                        ps.setInt(2, item.getFoodId());
                        ps.setInt(3, item.getQuantity());
                        ps.setBigDecimal(4, BigDecimal.valueOf(item.getPrice()));
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                con.commit();
                return orderId;
            } catch (SQLException | RuntimeException exception) {
                try {
                    con.rollback();
                } catch (SQLException rollbackException) {
                    exception.addSuppressed(rollbackException);
                }
                throw exception;
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    public List<Order> getOrdersForUser(int userId) throws SQLException {
        String sql = "SELECT order_id, user_id, total_amount, status, order_date "
                + "FROM orders WHERE user_id = ? ORDER BY order_date DESC";
        List<Order> orders = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    orders.add(readOrder(rs));
                }
            }
        }
        return orders;
    }

    public List<Order> getAllOrders() throws SQLException {
        String sql = "SELECT o.order_id, o.user_id, u.email, o.total_amount, o.status, o.order_date "
                + "FROM orders o JOIN users u ON u.user_id = o.user_id ORDER BY o.order_date DESC";
        List<Order> orders = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Order order = readOrder(rs);
                order.setCustomerEmail(rs.getString("email"));
                orders.add(order);
            }
        }
        return orders;
    }

    public boolean updateStatus(int orderId, String status) throws SQLException {
        if (!"Pending".equals(status) && !"Preparing".equals(status)
                && !"Out for delivery".equals(status) && !"Delivered".equals(status)
                && !"Cancelled".equals(status)) {
            throw new IllegalArgumentException("Choose a valid order status.");
        }
        String sql = "UPDATE orders SET status = ? WHERE order_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, orderId);
            return ps.executeUpdate() == 1;
        }
    }

    private static Order readOrder(ResultSet rs) throws SQLException {
        return new Order(rs.getInt("order_id"), rs.getInt("user_id"),
                rs.getDouble("total_amount"), rs.getString("status"),
                rs.getTimestamp("order_date"));
    }
}
