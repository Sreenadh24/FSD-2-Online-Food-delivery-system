package com.food.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.food.model.User;
import com.food.util.PasswordUtil;

public class UserDAO {
    public boolean registerUser(User user) throws SQLException {
        String sql = "INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, 'CUSTOMER')";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, user.getName().trim());
            ps.setString(2, user.getEmail().trim().toLowerCase());
            ps.setString(3, PasswordUtil.hash(user.getPassword()));
            ps.setString(4, user.getPhone().trim());
            return ps.executeUpdate() == 1;
        }
    }

    public User loginUser(String email, String password) throws SQLException {
        String sql = "SELECT user_id, name, email, password, phone, role FROM users WHERE LOWER(email) = ?";
        try (Connection con = DBConnection.getConnection()) {
            User user;
            String storedPassword;
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, email.trim().toLowerCase());
                try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                storedPassword = rs.getString("password");
                if (!PasswordUtil.verify(password, storedPassword)
                        && !password.equals(storedPassword)) {
                    return null;
                }
                user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setRole(rs.getString("role"));
                }
            }
            if (!storedPassword.startsWith("pbkdf2$")) {
                try (PreparedStatement update = con.prepareStatement(
                        "UPDATE users SET password = ? WHERE user_id = ?")) {
                    update.setString(1, PasswordUtil.hash(password));
                    update.setInt(2, user.getUserId());
                    update.executeUpdate();
                }
            }
            return user;
        }
    }
}
