package com.food.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DBConnection {

    private static final String DEFAULT_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String DEFAULT_USER = "onlinefood";
    private static final String DEFAULT_PASSWORD = "onlinefood123";

    private DBConnection() {
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "Oracle JDBC driver is missing from the deployed Food application.", e);
        }

        return DriverManager.getConnection(
                setting("ONLINEFOOD_DB_URL", DEFAULT_URL),
                setting("ONLINEFOOD_DB_USER", DEFAULT_USER),
                setting("ONLINEFOOD_DB_PASSWORD", DEFAULT_PASSWORD));
    }

    private static String setting(String name, String fallback) {
        String value = System.getenv(name);
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }
}