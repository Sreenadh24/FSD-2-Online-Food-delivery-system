package com.food.model;

import java.io.Serializable;

public class Food implements Serializable {
    private static final long serialVersionUID = 1L;


    private int foodId;
    private String name;
    private String description;
    private double price;
    private String category;
    private String image;

    public Food() {
    }

    public Food(int foodId, String name, String description,
                double price, String category, String image) {

        this.foodId = foodId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.image = image;
    }

    public Food(String name, String description,
                double price, String category, String image) {

        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.image = image;
    }

    public int getFoodId() {
        return foodId;
    }

    public void setFoodId(int foodId) {
        this.foodId = foodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
