package com.food.model;

import java.io.Serializable;

public class CartItem implements Serializable {
    private static final long serialVersionUID = 1L;

    private Food food;
    private int quantity;

    public CartItem() {
    }

    public CartItem(Food food, int quantity) {
        this.food = food;
        this.quantity = quantity;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getFoodId() {
        return food != null ? food.getFoodId() : 0;
    }

    public double getPrice() {
        return food != null ? food.getPrice() : 0.0;
    }

    public double getTotal() {
        return getPrice() * quantity;
    }

    public double getTotalPrice() {
        return getTotal();
    }
}