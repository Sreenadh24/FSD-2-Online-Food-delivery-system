package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.UserDAO;
import com.food.model.User;

@WebServlet("/adminLogin")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        if (email == null || password == null || email.trim().isEmpty() || password.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?admin=1&error=invalid");
            return;
        }

        User user;
        try {
            user = new UserDAO().loginUser(email, password);
        } catch (SQLException exception) {
            throw new ServletException("Unable to sign in to the administrator account.", exception);
        }
        if (user == null || !user.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?admin=1&error=invalid");
            return;
        }

        HttpSession session = request.getSession(true);
        request.changeSessionId();
        session.setAttribute("user", user);
        response.sendRedirect(request.getContextPath() + "/admin/foods");
    }
}
