package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.OrderDAO;
import com.food.model.CartItem;
import com.food.model.Order;
import com.food.model.User;

@WebServlet("/placeOrder")
public class PlaceOrderServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
            session.getAttribute("user") == null) {

            response.sendRedirect("login.jsp");
            return;
        }

        User user = (User) session.getAttribute("user");

        Object cartObject = session.getAttribute("cart");

        if (!(cartObject instanceof List<?>)) {
            response.sendRedirect("cart.jsp");
            return;
        }

        List<?> items = (List<?>) cartObject;

        if (items.isEmpty()) {
            response.sendRedirect("cart.jsp");
            return;
        }

        for (Object item : items) {
            if (!(item instanceof CartItem)) {
                response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Invalid cart item"
                );
                return;
            }
        }

        @SuppressWarnings("unchecked")
        List<CartItem> cart = (List<CartItem>) items;

        for (CartItem item : cart) {
            if (item == null || item.getQuantity() <= 0 || item.getQuantity() > 50) {

                response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Invalid product quantity or price"
                );
                return;
            }

        }

        Order order = new Order();
        order.setUserId(user.getUserId());
        order.setStatus("Pending");

        OrderDAO dao = new OrderDAO();

        int orderId;
        try {
            orderId = dao.placeOrder(order, cart);
        } catch (IllegalArgumentException exception) {
            response.sendRedirect(request.getContextPath() + "/cart.jsp?error=invalid");
            return;
        } catch (SQLException exception) {
            throw new ServletException("Unable to place the order. Check the database connection.", exception);
        }

        if (orderId > 0) {
            session.removeAttribute("cart");

            response.sendRedirect(request.getContextPath()
                    + "/order-success.jsp?orderId=" + orderId);
        } else {
            response.sendRedirect(request.getContextPath() + "/cart.jsp?error=orderFailed");
        }
    }
}