package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.UserDAO;
import com.food.model.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        if (email == null || password == null
                || email.trim().isEmpty() || password.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=invalid");
            return;
        }

        UserDAO dao = new UserDAO();

        User user;
        try {
            user = dao.loginUser(email, password);
        } catch (SQLException exception) {
            throw new ServletException("Unable to sign in. Check the database connection.", exception);
        }

        if (user != null) {

            HttpSession session = request.getSession(true);
            request.changeSessionId();
            session.setAttribute("user", user);

            response.sendRedirect(request.getContextPath() + "/menu");

        } else {

            response.sendRedirect(request.getContextPath() + "/login.jsp?error=invalid");
        }
    }
}