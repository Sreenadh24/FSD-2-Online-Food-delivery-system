package com.food.controller;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.model.CartItem;

@WebServlet("/removeFromCart")
public class RemoveFromCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        List<CartItem> cart = session == null ? null : (List<CartItem>) session.getAttribute("cart");
        try {
            int foodId = Integer.parseInt(request.getParameter("foodId"));
            if (cart != null) {
                Iterator<CartItem> iterator = cart.iterator();
                while (iterator.hasNext()) {
                    if (iterator.next().getFoodId() == foodId) {
                        iterator.remove();
                        break;
                    }
                }
            }
            response.sendRedirect(request.getContextPath() + "/cart.jsp");
        } catch (NumberFormatException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid food item.");
        }
    }
}
