package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.food.dao.FoodDAO;
import com.food.model.Food;
import com.food.util.FoodImageUpload;
import com.food.util.UrlUtil;

@WebServlet("/updateFood")
@MultipartConfig(maxFileSize = 5 * 1024 * 1024, maxRequestSize = 6 * 1024 * 1024)
public class UpdateFoodServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int foodId;
        double price;
        try {
            foodId = Integer.parseInt(request.getParameter("foodId"));
            price = Double.parseDouble(request.getParameter("price"));
        } catch (NumberFormatException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Enter a valid item ID and price.");
            return;
        }

        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String category = request.getParameter("category");
        String image = request.getParameter("image");
        Part imageFile = request.getPart("imageFile");
        if (foodId < 1 || !Double.isFinite(price) || price <= 0
                || name == null || description == null || category == null || image == null
                || name.trim().isEmpty() || category.trim().isEmpty()
                || (imageFile.getSize() == 0 && !UrlUtil.isHttpUrl(image.trim())
                    && !FoodImageUpload.isStoredImagePath(image.trim()))) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "Complete the food fields with a positive price and valid image URL.");
            return;
        }

        if (imageFile.getSize() > 0) {
            try {
                image = FoodImageUpload.save(request, imageFile);
            } catch (IOException exception) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, exception.getMessage());
                return;
            }
        } else {
            image = image.trim();
        }

        Food food = new Food(foodId, name.trim(), description.trim(), price,
                category.trim(), image.trim());
        try {
            if (new FoodDAO().updateFood(food)) {
                response.sendRedirect(request.getContextPath() + "/admin/foods");
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Food item not found.");
            }
        } catch (SQLException exception) {
            throw new ServletException("Unable to update the food item.", exception);
        }
    }
}
