package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.dao.FoodDAO;

@WebServlet("/deleteFood")
public class DeleteFoodServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        int foodId;
        try {
            foodId = Integer.parseInt(request.getParameter("id"));
        } catch (NumberFormatException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid food item.");
            return;
        }
        try {
            if (new FoodDAO().deleteFood(foodId)) {
                response.sendRedirect(request.getContextPath() + "/admin/foods");
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Food item not found.");
            }
        } catch (SQLException exception) {
            throw new ServletException("Unable to delete the food item.", exception);
        }
    }
}
