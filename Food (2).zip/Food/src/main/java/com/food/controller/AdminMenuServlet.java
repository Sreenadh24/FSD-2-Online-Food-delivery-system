package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.dao.FoodDAO;

@WebServlet("/admin/foods")
public class AdminMenuServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("foods", new FoodDAO().getAllFood());
            request.getRequestDispatcher("/admin-food.jsp").forward(request, response);
        } catch (SQLException exception) {
            throw new ServletException("Unable to load food management.", exception);
        }
    }
}
