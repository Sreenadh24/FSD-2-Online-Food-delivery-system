package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.FoodDAO;
import com.food.model.CartItem;
import com.food.model.Food;

@WebServlet("/addToCart")
public class AddToCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int foodId = Integer.parseInt(request.getParameter("foodId"));
            Food food = new FoodDAO().getFoodById(foodId);
            if (food == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Food item not found.");
                return;
            }

            HttpSession session = request.getSession();
            @SuppressWarnings("unchecked")
            List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
            if (cart == null) {
                cart = new ArrayList<>();
                session.setAttribute("cart", cart);
            }
            CartItem found = null;
            for (CartItem item : cart) {
                if (item.getFoodId() == foodId) {
                    found = item;
                    break;
                }
            }
            if (found == null) {
                cart.add(new CartItem(food, 1));
            } else if (found.getQuantity() < 50) {
                found.setQuantity(found.getQuantity() + 1);
            }
            response.sendRedirect(request.getContextPath() + "/cart.jsp");
        } catch (NumberFormatException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid food item.");
        } catch (SQLException exception) {
            throw new ServletException("Unable to add the item to your cart.", exception);
        }
    }
}
