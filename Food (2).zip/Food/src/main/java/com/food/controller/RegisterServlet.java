package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.dao.UserDAO;
import com.food.model.User;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        if (name == null || email == null || password == null || phone == null
                || name.trim().isEmpty() || email.trim().isEmpty()
                || password.length() < 8 || password.length() > 128 || phone.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/register.jsp?error=invalid");
            return;
        }

        User user = new User();

        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);

        UserDAO dao = new UserDAO();

        try {
            if (dao.registerUser(user)) {
                response.sendRedirect(request.getContextPath() + "/login.jsp?registered=1");
            } else {
                response.sendRedirect(request.getContextPath() + "/register.jsp?error=failed");
            }
        } catch (SQLException exception) {
            if (exception.getErrorCode() == 1) {
                response.sendRedirect(request.getContextPath() + "/register.jsp?error=duplicate");
                return;
            }
            throw new ServletException("Unable to create your account. Check the database connection.", exception);
        }
    }
}
