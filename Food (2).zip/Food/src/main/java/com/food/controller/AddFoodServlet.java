package com.food.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.food.dao.FoodDAO;
import com.food.model.Food;
import com.food.util.FoodImageUpload;
import com.food.util.UrlUtil;

@WebServlet("/addFood")
@MultipartConfig(maxFileSize = 5 * 1024 * 1024, maxRequestSize = 6 * 1024 * 1024)
public class AddFoodServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String priceString = request.getParameter("price");
        String category = request.getParameter("category");
        String image = request.getParameter("image");
        Part imageFile = request.getPart("imageFile");
        if (name == null || description == null || priceString == null
                || category == null || name.trim().isEmpty() || category.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Complete all required food fields.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceString);
        } catch (NumberFormatException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Enter a valid food price.");
            return;
        }
        if (!Double.isFinite(price) || price <= 0) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Price must be greater than zero.");
            return;
        }

        Food food = new Food();

        food.setName(name);
        food.setDescription(description);
        food.setPrice(price);
        food.setCategory(category);
        String imageUrl = image == null ? "" : image.trim();
        if (imageFile.getSize() == 0 && !UrlUtil.isHttpUrl(imageUrl)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "Provide an HTTP(S) image URL or upload a JPEG, PNG, GIF, or WebP image.");
            return;
        }

        try {
            if (imageFile.getSize() > 0) {
                imageUrl = FoodImageUpload.save(request, imageFile);
            }
        } catch (IOException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, exception.getMessage());
            return;
        }
        food.setImage(imageUrl);

        FoodDAO dao = new FoodDAO();
        try {
            if (dao.addFood(food)) {
                response.sendRedirect(request.getContextPath() + "/admin/foods");
            } else {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Food item was not saved.");
            }
        } catch (SQLException exception) {
            throw new ServletException("Unable to add the food item.", exception);
        }
    }
}
