package com.food.controller;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.model.CartItem;

@WebServlet("/updateCart")
public class UpdateCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        List<CartItem> cart = session == null ? null : (List<CartItem>) session.getAttribute("cart");
        try {
            int foodId = Integer.parseInt(request.getParameter("foodId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            if (cart == null || quantity < 0 || quantity > 50) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Quantity must be from 0 to 50.");
                return;
            }
            Iterator<CartItem> iterator = cart.iterator();
            while (iterator.hasNext()) {
                CartItem item = iterator.next();
                if (item.getFoodId() == foodId) {
                    if (quantity == 0) {
                        iterator.remove();
                    } else {
                        item.setQuantity(quantity);
                    }
                    response.sendRedirect(request.getContextPath() + "/cart.jsp");
                    return;
                }
            }
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Cart item not found.");
        } catch (NumberFormatException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid item or quantity.");
        }
    }
}
