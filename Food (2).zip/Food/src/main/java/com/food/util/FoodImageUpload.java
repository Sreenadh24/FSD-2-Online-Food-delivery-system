package com.food.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

public final class FoodImageUpload {
    private static final long MAX_IMAGE_SIZE = 5L * 1024 * 1024;

    private FoodImageUpload() {
    }

    public static String save(HttpServletRequest request, Part imagePart) throws IOException {
        if (imagePart == null || imagePart.getSize() == 0) {
            return null;
        }
        if (imagePart.getSize() > MAX_IMAGE_SIZE) {
            throw new IOException("Food images must be 5 MB or smaller.");
        }

        String extension = imageExtension(imagePart);
        if (extension == null) {
            throw new IOException("Upload a valid JPEG, PNG, GIF, or WebP image.");
        }

        ServletContext context = request.getServletContext();
        String uploadDirectory = context.getRealPath("/assets/uploads");
        if (uploadDirectory == null) {
            throw new IOException("The server does not provide a writable upload directory.");
        }

        String fileName = UUID.randomUUID().toString() + extension;
        Path destinationDirectory = Paths.get(uploadDirectory);
        Files.createDirectories(destinationDirectory);
        try (InputStream input = imagePart.getInputStream()) {
            Files.copy(input, destinationDirectory.resolve(fileName));
        }
        return "/assets/uploads/" + fileName;
    }

    private static String imageExtension(Part imagePart) throws IOException {
        byte[] header = new byte[12];
        int count = 0;
        try (InputStream input = imagePart.getInputStream()) {
            while (count < header.length) {
                int bytesRead = input.read(header, count, header.length - count);
                if (bytesRead < 0) {
                    break;
                }
                count += bytesRead;
            }
        }
        if (count >= 3 && (header[0] & 0xff) == 0xff
                && (header[1] & 0xff) == 0xd8 && (header[2] & 0xff) == 0xff) {
            return ".jpg";
        }
        if (count >= 8 && (header[0] & 0xff) == 0x89
                && header[1] == 'P' && header[2] == 'N' && header[3] == 'G'
                && header[4] == 0x0d && header[5] == 0x0a
                && header[6] == 0x1a && header[7] == 0x0a) {
            return ".png";
        }
        if (count >= 6 && header[0] == 'G' && header[1] == 'I'
                && header[2] == 'F' && header[3] == '8'
                && (header[4] == '7' || header[4] == '9') && header[5] == 'a') {
            return ".gif";
        }
        if (count >= 12 && header[0] == 'R' && header[1] == 'I'
                && header[2] == 'F' && header[3] == 'F'
                && header[8] == 'W' && header[9] == 'E'
                && header[10] == 'B' && header[11] == 'P') {
            return ".webp";
        }
        return null;
    }

    public static boolean isStoredImagePath(String image) {
        String prefix = "/assets/uploads/";
        if (image == null || !image.startsWith(prefix)) {
            return false;
        }
        String fileName = image.substring(prefix.length());
        int extensionIndex = fileName.lastIndexOf('.');
        if (extensionIndex < 0) {
            return false;
        }
        String extension = fileName.substring(extensionIndex).toLowerCase();
        if (!".jpg".equals(extension) && !".png".equals(extension)
                && !".gif".equals(extension) && !".webp".equals(extension)) {
            return false;
        }
        String uuid = fileName.substring(0, extensionIndex);
        try {
            return UUID.fromString(uuid).toString().equalsIgnoreCase(uuid);
        } catch (IllegalArgumentException exception) {
            return false;
        }
    }
}
