package com.food.util;

public class TemporaryPasswordHash {
    public static void main(String[] args) {
        System.out.println(PasswordUtil.hash("admin123"));
    }
}