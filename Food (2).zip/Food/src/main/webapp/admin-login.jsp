<%
    response.sendRedirect(request.getContextPath() + "/login.jsp?admin=1");
%>
