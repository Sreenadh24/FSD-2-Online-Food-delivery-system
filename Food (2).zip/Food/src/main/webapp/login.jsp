<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.food.util.HtmlUtil" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<%
    boolean adminMode = "1".equals(request.getParameter("admin"));
    String formAction = adminMode ? "/adminLogin" : "/login";
%>
<main class="container narrow">
    <section class="form-card">
        <p class="eyebrow"><%= adminMode ? "ADMIN WORKSPACE" : "WELCOME BACK" %></p>
        <h1><%= adminMode ? "Administrator sign in" : "Sign in" %></h1>
        <% if ("invalid".equals(request.getParameter("error"))) { %>
            <div class="alert"><%= adminMode
                    ? "Administrator email or password is incorrect."
                    : "Email or password is incorrect." %></div>
        <% } else if ("1".equals(request.getParameter("registered"))) { %>
            <div class="success">Your account is ready. Sign in to start ordering.</div>
        <% } %>
        <form method="post" action="<%= request.getContextPath() + formAction %>" class="form-stack">
            <label>Email address<input type="email" name="email" autocomplete="username" required></label>
            <label>Password<input type="password" name="password" autocomplete="current-password" required></label>
            <button class="button button-primary button-wide" type="submit">
                <%= adminMode ? "Sign in as admin" : "Sign in" %>
            </button>
        </form>
        <% if (adminMode) { %>
            <p class="form-foot"><a href="<%= request.getContextPath() %>/login.jsp">Customer sign in</a></p>
        <% } else { %>
            <p class="form-foot">New here? <a href="<%= request.getContextPath() %>/register.jsp">Create an account</a></p>
            <p class="form-foot"><a href="<%= request.getContextPath() %>/login.jsp?admin=1">Administrator sign in</a></p>
        <% } %>
    </section>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
