<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<main class="container narrow">
    <section class="form-card">
        <p class="eyebrow">JOIN THE TABLE</p>
        <h1>Create account</h1>
        <% String error = request.getParameter("error");
           if ("duplicate".equals(error)) { %>
            <div class="alert">An account with that email already exists.</div>
        <% } else if ("invalid".equals(error)) { %>
            <div class="alert">Enter all details and choose a password with at least 8 characters.</div>
        <% } else if ("failed".equals(error)) { %>
            <div class="alert">We couldn't create the account. Please try again.</div>
        <% } %>
        <form method="post" action="<%= request.getContextPath() %>/register" class="form-stack">
            <label>Your name<input type="text" name="name" maxlength="100" autocomplete="name" required></label>
            <label>Email address<input type="email" name="email" maxlength="190" autocomplete="email" required></label>
            <label>Phone<input type="tel" name="phone" maxlength="30" autocomplete="tel" required></label>
            <label>Password<input type="password" name="password" minlength="8" maxlength="128" autocomplete="new-password" required></label>
            <button class="button button-primary button-wide" type="submit">Create account</button>
        </form>
        <p class="form-foot">Already have an account? <a href="<%= request.getContextPath() %>/login.jsp">Sign in</a></p>
    </section>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
