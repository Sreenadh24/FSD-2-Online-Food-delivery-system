<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,com.food.model.Food,com.food.model.User,com.food.util.HtmlUtil" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<main class="container">
    <section class="hero">
        <div><p class="eyebrow">GOOD FOOD, DELIVERED</p><h1>Your next favorite meal is just a click away.</h1>
            <p>Freshly prepared favorites, delivered right to your door.</p><a class="button button-light" href="#menu">Explore the menu</a></div>
        <div class="hero-mark" aria-hidden="true">🍽</div>
    </section>
    <section id="menu" class="section-heading"><div><p class="eyebrow">MADE WITH CARE</p><h2>Today's menu</h2></div></section>
    <%
        List<Food> foods = (List<Food>) request.getAttribute("foods");
        if (foods == null || foods.isEmpty()) {
    %>
        <div class="empty-state"><h3>Our kitchen is getting ready</h3><p>Please check back soon for today's menu.</p></div>
    <% } else { %>
        <div class="food-grid">
        <% for (Food food : foods) { %>
            <article class="food-card">
                <img src="<%= HtmlUtil.escape(food.getImage().startsWith("/assets/uploads/")
                        ? request.getContextPath() + food.getImage() : food.getImage()) %>"
                     alt="<%= HtmlUtil.escape(food.getName()) %>"
                     onerror="this.src='<%= request.getContextPath() %>/assets/food-placeholder.svg'">
                <div class="food-card-body">
                    <span class="food-category"><%= HtmlUtil.escape(food.getCategory()) %></span>
                    <h3><%= HtmlUtil.escape(food.getName()) %></h3>
                    <p><%= HtmlUtil.escape(food.getDescription()) %></p>
                    <div class="food-card-bottom"><strong>₹<%= String.format("%.2f", food.getPrice()) %></strong>
                        <form method="post" action="<%= request.getContextPath() %>/addToCart">
                            <input type="hidden" name="foodId" value="<%= food.getFoodId() %>">
                            <button class="button button-primary" type="submit">Add to cart</button>
                        </form>
                    </div>
                </div>
            </article>
        <% } %>
        </div>
    <% } %>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
