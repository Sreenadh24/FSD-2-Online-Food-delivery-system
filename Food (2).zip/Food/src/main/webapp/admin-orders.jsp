<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,java.text.SimpleDateFormat,com.food.model.Order,com.food.util.HtmlUtil" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<main class="container">
    <div class="page-title"><div><p class="eyebrow">ADMIN WORKSPACE</p><h1>Manage orders</h1></div></div>
    <%
        List<Order> orders = (List<Order>) request.getAttribute("orders");
        if (orders == null || orders.isEmpty()) {
    %>
        <div class="empty-state"><h2>No orders yet</h2><p>Customer orders will appear here.</p></div>
    <% } else { %>
        <div class="table-wrap"><table>
            <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th>Update</th></tr></thead>
            <tbody>
            <% for (Order order : orders) { %>
                <tr>
                    <td>#<%= order.getOrderId() %></td>
                    <td><%= HtmlUtil.escape(order.getCustomerEmail()) %></td>
                    <td><%= order.getOrderDate() == null ? "" : new SimpleDateFormat("MMM d, yyyy h:mm a").format(order.getOrderDate()) %></td>
                    <td>₹<%= String.format("%.2f", order.getTotalAmount()) %></td>
                    <td><span class="status"><%= HtmlUtil.escape(order.getStatus()) %></span></td>
                    <td>
                        <form class="inline-form" method="post" action="<%= request.getContextPath() %>/updateOrder">
                            <input type="hidden" name="orderId" value="<%= order.getOrderId() %>">
                            <select name="status" aria-label="Status for order <%= order.getOrderId() %>">
                                <option value="Pending" <%= "Pending".equals(order.getStatus()) ? "selected" : "" %>>Pending</option>
                                <option value="Preparing" <%= "Preparing".equals(order.getStatus()) ? "selected" : "" %>>Preparing</option>
                                <option value="Out for delivery" <%= "Out for delivery".equals(order.getStatus()) ? "selected" : "" %>>Out for delivery</option>
                                <option value="Delivered" <%= "Delivered".equals(order.getStatus()) ? "selected" : "" %>>Delivered</option>
                                <option value="Cancelled" <%= "Cancelled".equals(order.getStatus()) ? "selected" : "" %>>Cancelled</option>
                            </select>
                            <button class="button button-small button-secondary" type="submit">Save</button>
                        </form>
                    </td>
                </tr>
            <% } %>
            </tbody>
        </table></div>
    <% } %>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
