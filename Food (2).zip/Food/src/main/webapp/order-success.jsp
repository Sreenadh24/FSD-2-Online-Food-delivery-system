<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<main class="container narrow">
    <section class="form-card confirmation">
        <div class="confirmation-icon" aria-hidden="true">✓</div>
        <p class="eyebrow">ORDER CONFIRMED</p>
        <h1>Thanks for your order!</h1>
        <p>Your order number is <strong>#<%= request.getParameter("orderId") == null ? "" : request.getParameter("orderId").replaceAll("[^0-9]", "") %></strong>. Payment is due on delivery.</p>
        <a class="button button-primary" href="<%= request.getContextPath() %>/myOrders">Track your orders</a>
    </section>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
