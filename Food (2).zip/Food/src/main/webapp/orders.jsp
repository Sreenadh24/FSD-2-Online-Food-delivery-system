<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,java.text.SimpleDateFormat,com.food.model.Order,com.food.util.HtmlUtil" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<main class="container">
    <div class="page-title"><div><p class="eyebrow">YOUR HISTORY</p><h1>Your orders</h1></div></div>
    <%
        List<Order> orders = (List<Order>) request.getAttribute("orders");
        if (orders == null || orders.isEmpty()) {
    %>
        <div class="empty-state"><h2>No orders yet</h2><p>Your next favorite meal is waiting.</p>
            <a class="button button-primary" href="<%= request.getContextPath() %>/menu">Explore menu</a></div>
    <% } else { %>
        <div class="table-wrap"><table><thead><tr><th>Order</th><th>Date</th><th>Total</th><th>Status</th></tr></thead><tbody>
        <% for (Order order : orders) { %>
            <tr><td>#<%= order.getOrderId() %></td>
                <td><%= order.getOrderDate() == null ? "" : new SimpleDateFormat("MMM d, yyyy h:mm a").format(order.getOrderDate()) %></td>
                <td>₹<%= String.format("%.2f", order.getTotalAmount()) %></td>
                <td><span class="status"><%= HtmlUtil.escape(order.getStatus()) %></span></td></tr>
        <% } %>
        </tbody></table></div>
    <% } %>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
