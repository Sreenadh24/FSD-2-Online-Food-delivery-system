<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,com.food.model.CartItem,com.food.util.HtmlUtil" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<main class="container">
    <div class="page-title"><div><p class="eyebrow">YOUR ORDER</p><h1>Shopping cart</h1></div></div>
    <% if ("invalid".equals(request.getParameter("error"))) { %>
        <div class="alert">A cart item is unavailable or has an invalid quantity. Please review your cart.</div>
    <% } else if ("orderFailed".equals(request.getParameter("error"))) { %>
        <div class="alert">We couldn't place the order. Your cart is still saved; please try again.</div>
    <% } %>
    <%
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
    %>
        <div class="empty-state"><h2>Your cart is empty</h2><p>Pick something delicious from the menu.</p>
            <a class="button button-primary" href="<%= request.getContextPath() %>/menu">Browse menu</a></div>
    <% } else {
           double total = 0;
    %>
        <div class="table-wrap"><table><thead><tr><th>Item</th><th>Price</th><th>Quantity</th><th>Total</th><th></th></tr></thead><tbody>
        <% for (CartItem item : cart) {
               total += item.getTotal();
        %>
            <tr><td><strong><%= HtmlUtil.escape(item.getFood().getName()) %></strong></td>
                <td>₹<%= String.format("%.2f", item.getPrice()) %></td>
                <td><form class="inline-form" method="post" action="<%= request.getContextPath() %>/updateCart">
                    <input type="hidden" name="foodId" value="<%= item.getFoodId() %>">
                    <input class="quantity-input" type="number" name="quantity" min="0" max="50" value="<%= item.getQuantity() %>" required>
                    <button class="button button-small button-secondary" type="submit">Update</button>
                </form></td>
                <td>₹<%= String.format("%.2f", item.getTotal()) %></td>
                <td><form method="post" action="<%= request.getContextPath() %>/removeFromCart">
                    <input type="hidden" name="foodId" value="<%= item.getFoodId() %>">
                    <button class="text-button" type="submit">Remove</button>
                </form></td>
            </tr>
        <% } %>
        </tbody></table></div>
        <div class="cart-actions"><div><strong>Subtotal: ₹<%= String.format("%.2f", total) %></strong><br>
            <a href="<%= request.getContextPath() %>/menu">Continue shopping</a></div>
            <form method="post" action="<%= request.getContextPath() %>/placeOrder">
                <button class="button button-primary" type="submit">Place order · cash on delivery</button>
            </form>
        </div>
    <% } %>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
