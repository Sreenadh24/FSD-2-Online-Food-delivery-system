<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,com.food.model.Food,com.food.util.HtmlUtil" %>
<%@ include file="WEB-INF/views/header.jspf" %>
<main class="container">
    <div class="page-title"><div><p class="eyebrow">ADMIN WORKSPACE</p><h1>Manage menu</h1></div></div>
    <section class="form-card admin-create">
        <h2>Add a food item</h2>
        <form class="admin-food-form" method="post" enctype="multipart/form-data" action="<%= request.getContextPath() %>/addFood">
            <label>Name<input name="name" maxlength="120" required></label>
            <label>Description<input name="description" maxlength="500" required></label>
            <label>Price (₹)<input type="number" name="price" min="0.01" step="0.01" required></label>
            <label>Category<input name="category" maxlength="80" required></label>
            <label>Image URL (optional)<input type="url" name="image" maxlength="1000"></label>
            <label>Or upload image (JPEG, PNG, GIF, WebP; max 5 MB)<input type="file" name="imageFile" accept="image/jpeg,image/png,image/gif,image/webp"></label>
            <button class="button button-primary" type="submit">Add item</button>
        </form>
    </section>
    <%
        List<Food> foods = (List<Food>) request.getAttribute("foods");
        if (foods == null || foods.isEmpty()) {
    %>
        <div class="empty-state"><h2>No menu items yet</h2><p>Add the first item using the form above.</p></div>
    <% } else { %>
        <div class="admin-list">
        <% for (Food food : foods) { %>
            <section class="form-card admin-item">
                <form class="admin-food-form" method="post" enctype="multipart/form-data" action="<%= request.getContextPath() %>/updateFood">
                    <input type="hidden" name="foodId" value="<%= food.getFoodId() %>">
                    <label>Name<input name="name" maxlength="120" value="<%= HtmlUtil.escape(food.getName()) %>" required></label>
                    <label>Description<input name="description" maxlength="500" value="<%= HtmlUtil.escape(food.getDescription()) %>" required></label>
                    <label>Price (₹)<input type="number" name="price" min="0.01" step="0.01" value="<%= food.getPrice() %>" required></label>
                    <label>Category<input name="category" maxlength="80" value="<%= HtmlUtil.escape(food.getCategory()) %>" required></label>
                    <label>Image URL<input type="url" name="image" maxlength="1000" value="<%= HtmlUtil.escape(food.getImage()) %>" required></label>
                    <label>Replace with uploaded image (optional; JPEG, PNG, GIF, WebP; max 5 MB)<input type="file" name="imageFile" accept="image/jpeg,image/png,image/gif,image/webp"></label>
                    <button class="button button-secondary" type="submit">Save changes</button>
                </form>
                <form class="admin-delete" method="post" action="<%= request.getContextPath() %>/deleteFood"
                      onsubmit="return confirm('Delete this menu item?')">
                    <input type="hidden" name="id" value="<%= food.getFoodId() %>">
                    <button class="text-button" type="submit">Delete item</button>
                </form>
            </section>
        <% } %>
        </div>
    <% } %>
</main>
<%@ include file="WEB-INF/views/footer.jspf" %>
