# Onlinefood (Eclipse Dynamic Web Project)

An online food ordering web application built with Java 21, Java Servlets/JSP, Tomcat 9, and Oracle Database. It is configured as an Eclipse Dynamic Web Project and uses the Oracle JDBC driver already in `src/main/webapp/WEB-INF/lib/ojdbc17.jar`.

## Features

- Customer registration and sign-in with salted PBKDF2 password hashes
- Food menu, session shopping cart, quantity updates, and cash-on-delivery orders
- Customer order history
- Admin food create/update/delete and order status management
- Oracle JDBC persistence using prepared statements and transaction-backed order placement

## Run in the existing Eclipse workspace

1. Open the `Onlinefood` project in the Eclipse workspace shown in the screenshot.
2. Right-click the project and choose **Refresh** if the newly added files are not visible.
3. Check that Apache Tomcat 9 is selected for this project: **Properties → Targeted Runtimes**.
4. Set up Oracle XE as described below.
5. Right-click the project and choose **Run As → Run on Server**, select Tomcat 9, and open `http://localhost:8080/Onlinefood/`.

The source code uses Tomcat 9's `javax.servlet` API. Tomcat 10+ requires a Jakarta API migration.

## Oracle database setup

The schema script is `database/schema.sql`. It creates the tables and six sample menu items.

For a new local Oracle XE schema, connect as `SYSTEM` and run:

```sql
CREATE USER onlinefood IDENTIFIED BY onlinefood123;
GRANT CREATE SESSION, CREATE TABLE TO onlinefood;
ALTER USER onlinefood QUOTA UNLIMITED ON USERS;
```

Then connect as `ONLINEFOOD` and run `database/schema.sql` once. If the schema user already exists, do not run `CREATE USER` again.

Default JDBC settings match the local Eclipse demo:

| Environment variable | Default |
|---|---|
| `ONLINEFOOD_DB_URL` | `jdbc:oracle:thin:@localhost:1521:XE` |
| `ONLINEFOOD_DB_USER` | `onlinefood` |
| `ONLINEFOOD_DB_PASSWORD` | `onlinefood123` |

To change these for the Tomcat server in Eclipse, use **Run Configurations → Apache Tomcat → Environment**. Do not use the demo password for a real deployment.

## Admin account

1. Register `admin@gmail.com` from the application using a strong, unique password. Do not use the example password `admin` outside a disposable local demo.
2. Connect to the database as `ONLINEFOOD` and grant that account the admin role:

   ```sql
   UPDATE users SET role = 'ADMIN' WHERE email = 'admin@gmail.com';
   COMMIT;
   ```

3. Open `/login.jsp?admin=1` and sign in with that email and the password chosen during registration. The admin account can manage food and orders. Only accounts with role `ADMIN` are allowed into those routes.

New accounts use PBKDF2 password hashes; the `users.password` column stores the encoded hash rather than the original password.

Admin food forms accept either an HTTP(S) image URL or a JPEG, PNG, GIF, or WebP image upload (up to 5 MB). Uploads are stored under the deployed application's `assets/uploads` directory; use durable external storage for production deployments that replace the exploded web application.
